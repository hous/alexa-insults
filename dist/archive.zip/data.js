module.exports = {
	insults : [
		"You are a big dumb idiot.",
		"You don't dress well and everyone you know dislikes you.",
		"How are you still alive? You are so stupid I'm surprised you remember how breathe.",
		"You are tremendously average. There is literally nothing special about you.",
		"People talk about you when you're not around.",
		"You're horrible. Most people just tolerate you.",
		"When was the last time you had a good cry? I ask because you are a terrible excuse for a person and you should probably cry all the time.",
		"If anyone has ever loved you, they were wrong.",
		"How does it feel to be so mercifully free from the ravages of intelligence? Did you even understand that sentence?",
		"How does it feel to know that you are a complete disappointment and will amount to nothing?",
		"I'll bet even Mr. Rogers couldn't think of something nice to say about you.",
		"You are a terrible person and you should feel bad about yourself.",
		"If you have any self esteem you should donate it to someone who deserves it, because you are a talentless clown."
	]
}
