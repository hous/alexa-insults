module.exports = {
	"lambdaFunctionName" : "insults",
	"lambdaFunctionARN" : "arn:aws:lambda:us-east-1:959726898863:function:insults",
	"amazonAppId" : "amzn1.echo-sdk-ams.app.52bbd3ed-9533-4eda-ab19-3d5ad8840e6d",
	"skillTitle" : "Insults"
};